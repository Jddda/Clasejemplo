package com.example.segundoparcial;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    AppCompatButton btnLogin;
    EditText edtUsername, edtPassword;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtUsername = findViewById(R.id.edtUsername);
        edtPassword = findViewById(R.id.edtPassword);
        btnLogin = findViewById(R.id.btnLogin);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences prefs = getSharedPreferences("datos", Context.MODE_PRIVATE);
                String usuarioGuardado = prefs.getString("usuario", null);

                String username = edtUsername.getText().toString();
                String password = edtPassword.getText().toString();

                if (usuarioGuardado != null) {
                    startActivity(new Intent(MainActivity.this, RickAndMorty.class));
                    finish();
                    return;
                }

                btnLogin.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {


                        if (username.isEmpty() || password.isEmpty()) {
                            Toast.makeText(MainActivity.this,
                                    "Por favor llenar los campos", Toast.LENGTH_SHORT).show();
                        } else {

                            SharedPreferences.Editor editor = prefs.edit();
                            editor.putString("usuario", username);
                            editor.apply() ;

                            //Esto es para ir a la siguiente pantalla :))))
                            Intent intent = new Intent(MainActivity.this, RickAndMorty.class);
                            startActivity(intent);
                            finish();
                        }
                    }
                });


            }
        });
    }
}