package com.example.calculadora;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Spinner;
import android.widget.ArrayAdapter;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;

public class MainActivity extends AppCompatActivity {

    EditText edtCaja1, edtCaja2;
    TextView txtResultado;
    AppCompatButton btnCalcular;
    Spinner spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        edtCaja1 = findViewById(R.id.edtCaja1);
        edtCaja2 = findViewById(R.id.edtCaja2);
        txtResultado = findViewById(R.id.txtResultado);
        btnCalcular = findViewById(R.id.btnCalcular);
        spinner = findViewById(R.id.spinnerOperadores);


        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                R.array.operadores,
                android.R.layout.simple_spinner_item
        );

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);


        btnCalcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String val1 = edtCaja1.getText().toString();
                String val2 = edtCaja2.getText().toString();

                if (val1.isEmpty() || val2.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Por favor digita todos los campos", Toast.LENGTH_LONG).show();
                } else {
                    int a = Integer.parseInt(val1);
                    int b = Integer.parseInt(val2);

                    // Obtenemos el operador seleccionado en el spinner
                    String operador = spinner.getSelectedItem().toString();
                    double resultado = 0;

                    switch (operador) {
                        case "+":
                            resultado = a + b;
                            break;
                        case "-":
                            resultado = a - b;
                            break;
                        case "*":
                            resultado = a * b;
                            break;
                        case "/":
                            if (b != 0) {
                                resultado = (double) a / b;
                            } else {
                                Toast.makeText(MainActivity.this, "No se puede dividir por 0", Toast.LENGTH_SHORT).show();
                                return;
                            }
                            break;
                    }

                    txtResultado.setText("Resultado: " + resultado);
                }
            }
        });
    }
}
