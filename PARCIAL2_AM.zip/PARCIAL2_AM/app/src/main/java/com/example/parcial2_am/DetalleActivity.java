package com.example.parcial2_am;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.squareup.picasso.Picasso;

public class DetalleActivity extends AppCompatActivity {

    ImageView imgDetalle;
    TextView txtNombreDetalle, txtEstadoDetalle;
    Button btnCerrarSesion;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle);

        imgDetalle = findViewById(R.id.imgDetalle);
        txtNombreDetalle = findViewById(R.id.txtNombreDetalle);
        txtEstadoDetalle = findViewById(R.id.txtEstadoDetalle);
        btnCerrarSesion = findViewById(R.id.btnCerrarSesion);

        Intent intent = getIntent();
        String imagen = intent.getStringExtra("imagen");
        String nombre = intent.getStringExtra("nombre");
        String especie = intent.getStringExtra("especie");
        String estado = intent.getStringExtra("estado");

        Picasso.get().load(imagen).into(imgDetalle);
        txtNombreDetalle.setText(nombre);
        txtEstadoDetalle.setText(estado);

        btnCerrarSesion.setOnClickListener(v -> {
            SharedPreferences prefs = getSharedPreferences("datos", Context.MODE_PRIVATE);
            prefs.edit().clear().apply();

            Intent i = new Intent(DetalleActivity.this, MainActivity.class);
            startActivity(i);
            finish();
        });
    }
}

