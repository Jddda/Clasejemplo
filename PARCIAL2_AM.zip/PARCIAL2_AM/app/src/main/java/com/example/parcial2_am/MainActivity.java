package com.example.parcial2_am;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatButton;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.example.parcial2_am.adaptadores.PantallaInicio;

public class MainActivity extends AppCompatActivity {


    EditText edtUsuario, edtContrasena;

    AppCompatButton btnPantallaInicio;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences prefs = getSharedPreferences("datos", Context.MODE_PRIVATE);
        String usuarioGuardado = prefs.getString("usuario", null);

        if (usuarioGuardado != null) {
            startActivity(new Intent(MainActivity.this, PantallaInicioActivity.class));
            finish();
            return;
        }

        edtUsuario = findViewById(R.id.edtUsuario);
        edtContrasena = findViewById(R.id.edtContrasena);
        btnPantallaInicio = findViewById(R.id.btnPantallaInicio);

        btnPantallaInicio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String usuario = edtUsuario.getText().toString().trim();
                String contrasena = edtContrasena.getText().toString().trim();

                if (usuario.isEmpty() || contrasena.isEmpty()) {
                    Toast.makeText(MainActivity.this,
                            "Por favor llenar los campos", Toast.LENGTH_SHORT).show();
                } else {

                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putString("usuario", usuario);
                    editor.apply() ;

                    //Esto es para ir a la siguiente pantalla :))))
                    Intent intent = new Intent(MainActivity.this, PantallaInicioActivity.class);
                    startActivity(intent);
                    finish();
                }
            }
        });
    }
}