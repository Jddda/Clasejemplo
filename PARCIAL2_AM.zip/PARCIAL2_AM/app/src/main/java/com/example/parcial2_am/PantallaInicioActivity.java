package com.example.parcial2_am;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.parcial2_am.adaptadores.PantallaInicio;
import com.example.parcial2_am.clases.Usuario;

import java.util.ArrayList;
import java.util.List;

public class PantallaInicioActivity extends AppCompatActivity {

    RecyclerView recyclerUsuarios;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pantalla_inicio);

        recyclerUsuarios = findViewById(R.id.recyclerUsuarios);
        recyclerUsuarios.setLayoutManager(new LinearLayoutManager(this));

        List<Usuario> lista = new ArrayList<>();
        lista.add(new Usuario("https://www.writeups.org/wp-content/uploads/Sheldon-Cooper-Big-Bang-Theory-Jim-Parson.jpg", "Sheldon Cooper", "Alive", "Human"));
        lista.add(new Usuario("https://www.writeups.org/wp-content/uploads/Penny-Big-Bang-Theory-Kaley-Cuoco.jpg", "Penny", "Alive", "Human"));
        lista.add(new Usuario("https://www.writeups.org/wp-content/uploads/Leonard-Hofstadter-Big-Bang-Theory-Johnny-Galecki.jpg", "Leonard Hofstadter", "Alive", "Human"));
        lista.add(new Usuario("https://www.writeups.org/wp-content/uploads/Howard-Wolowitz-Big-Bang-Theory-Simon-Helberg.jpg", "Howard Wolowitz", "Alive", "Human"));


        PantallaInicio adaptador = new PantallaInicio(lista);
        recyclerUsuarios.setAdapter(adaptador);
    }
}

//