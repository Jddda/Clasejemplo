package com.example.ligas.Clases;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import com.example.ligas.R;

public class MainActivity extends AppCompatActivity {

    CardView cardSantaFe, cardAmerica, cardMillonarios, cardNacional, cardJunior, cardBucaramanga;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cardSantaFe = findViewById(R.id.cardSantaFe);
        cardAmerica = findViewById(R.id.cardAmerica);
        cardMillonarios = findViewById(R.id.cardMillonarios);
        cardNacional = findViewById(R.id.cardNacional);
        cardJunior = findViewById(R.id.cardJunior);
        cardBucaramanga = findViewById(R.id.cardBucaramanga);

        cardSantaFe.setOnClickListener(v -> abrirEquipo(Santafe.class));
        cardAmerica.setOnClickListener(v -> abrirEquipo(Cali.class));
        cardMillonarios.setOnClickListener(v -> abrirEquipo(Millonarios.class));
        cardNacional.setOnClickListener(v -> abrirEquipo(Nacional.class));
        cardJunior.setOnClickListener(v -> abrirEquipo(Junior.class));
        cardBucaramanga.setOnClickListener(v -> abrirEquipo(Bucaramanga.class));
    }

    private void abrirEquipo(Class<?> claseEquipo) {
        Intent intent = new Intent(this, claseEquipo);
        startActivity(intent);
    }
}
