package com.example.ligas.Clases;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ligas.R;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private EquipoAdaptador adaptador;
    private List<Equipo> listaEquipos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerEquipos);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        listaEquipos = new ArrayList<>();
        listaEquipos.add(new Equipo("Atlético Nacional", R.drawable.nacional));
        listaEquipos.add(new Equipo("Millonarios FC", R.drawable.Millonarios));
        listaEquipos.add(new Equipo("America Cali", R.drawable.Cali));
        listaEquipos.add(new Equipo("Junior FC", R.drawable.Junior));
        listaEquipos.add(new Equipo("Atlético Bucaramanga", R.drawable.bucaramanga));
        listaEquipos.add(new Equipo("Independiente de Santa Fe", R.drawable.santafe));

        adaptador = new EquipoAdaptador(listaEquipos, this::abrirPantallaEquipo);
        recyclerView.setAdapter(adaptador);
    }

    private void abrirPantallaEquipo(String nombreEquipo) {
        Intent intent = null;

        switch (nombreEquipo) {
            case "Atlético Nacional":
                intent = new Intent(this, Nacional.class);
                break;
            case "Millonarios FC":
                intent = new Intent(this, Millonarios.class);
                break;
            case "America de Cali":
                intent = new Intent(this, Cali.class);
                break;
            case "Junior FC":
                intent = new Intent(this, Junior.class);
                break;
            case "Atlético Bucaramanga":
                intent = new Intent(this, Bucaramanga.class);
                break;
            case "Independiente de Santa Fe":
                intent = new Intent(this, Santafe.class);
                break;
        }

        if (intent != null) startActivity(intent);
    }
}
