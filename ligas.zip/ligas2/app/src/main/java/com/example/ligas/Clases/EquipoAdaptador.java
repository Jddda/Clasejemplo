package com.example.ligas.Clases;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.ligas.R;

import java.util.List;

public class EquipoAdaptador extends RecyclerView.Adapter<EquipoAdaptador.ViewHolder> {

    private List<Equipo> listaEquipos;
    private OnEquipoClickListener listener;

    public interface OnEquipoClickListener {
        void onEquipoClick(String nombreEquipo);
    }

    public EquipoAdaptador(List<Equipo> listaEquipos, OnEquipoClickListener listener) {
        this.listaEquipos = listaEquipos;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_equipo, parent, false);
        return new ViewHolder(vista);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Equipo equipo = listaEquipos.get(position);
        holder.txtNombre.setText(equipo.getNombre());
        holder.imgEquipo.setImageResource(equipo.getImagen());

        holder.imgEquipo.setOnClickListener(v ->
                listener.onEquipoClick(equipo.getNombre())
        );
    }

    @Override
    public int getItemCount() {
        return listaEquipos.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imgEquipo;
        TextView txtNombre;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgEquipo = itemView.findViewById(R.id.imgEquipo);
            txtNombre = itemView.findViewById(R.id.txtNombreEquipo);
        }
    }
}
