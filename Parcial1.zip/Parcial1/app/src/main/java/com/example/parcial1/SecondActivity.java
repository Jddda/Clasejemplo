package com.example.parcial1;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {

    TextView txtNombre, txtTeoria1, txtTeoria2, txtTeoria3, txtTeoria4, txtTeoria5, txtTeoria6, txtTeoria7, txtTeoria8;
    Button btnVolver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);


        txtNombre = findViewById(R.id.txtNombre);
        txtTeoria1 = findViewById(R.id.txtTeoria1);
        txtTeoria2 = findViewById(R.id.txtTeoria2);
        txtTeoria3 = findViewById(R.id.txtTeoria3);
        txtTeoria4 = findViewById(R.id.txtTeoria4);
        txtTeoria5 = findViewById(R.id.txtTeoria5);
        txtTeoria6 = findViewById(R.id.txtTeoria6);
        txtTeoria7 = findViewById(R.id.txtTeoria7);
        txtTeoria8 = findViewById(R.id.txtTeoria8);
        btnVolver = findViewById(R.id.btnVolver);


        txtNombre.setText("José Díaz Ariza");

        txtTeoria1.setText("Punto 1: Introducción a Android");
        txtTeoria2.setText("Punto 2: Android Studio");
        txtTeoria3.setText("Punto 3: Aplicaciones multiplataforma");
        txtTeoria4.setText("Punto 4: Lenguaje Java");
        txtTeoria5.setText("Punto 5: Aplicaciones nativas");
        txtTeoria6.setText("Punto 6: Aplicaciones híbridas");
        txtTeoria7.setText("Punto 7: Patrón MVC - Controller");
        txtTeoria8.setText("Punto 8: Archivos XML en Android");


        btnVolver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent volverIntent = new Intent(SecondActivity.this, MainActivity.class);
                startActivity(volverIntent);
                finish(); // opcional: cierra esta Activity para que no quede en la pila
            }
        });
    }
}