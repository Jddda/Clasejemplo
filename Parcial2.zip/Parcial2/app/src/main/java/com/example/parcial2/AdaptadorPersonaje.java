package com.example.parcial2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

import de.hdodenhof.circleimageview.CircleImageView;

public class AdaptadorPersonaje extends RecyclerView.Adapter<AdaptadorPersonaje.ViewHolder> {

    private List<Personaje> lista;
    private Context context;

    public AdaptadorPersonaje(Context context, List<Personaje> lista) {
        this.context = context;
        this.lista = lista;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_persojanes, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Personaje p = lista.get(position);
        holder.txtNombre.setText(p.getNombre());
        holder.txtEstado.setText(p.getEstado());
        holder.txtEspecie.setText(p.getEspecie());

        Picasso.get().load(p.getImagenUrl()).into(holder.imgPersonaje);

        holder.btnVerMas.setOnClickListener(v ->
                Toast.makeText(context, "Ver más de " + p.getNombre(), Toast.LENGTH_SHORT).show()
        );
    }

    @Override
    public int getItemCount() {
        return lista.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        CircleImageView imgPersonaje;
        TextView txtNombre, txtEstado, txtEspecie;
        Button btnVerMas;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imgPersonaje = itemView.findViewById(R.id.imgPersonaje);
            txtNombre = itemView.findViewById(R.id.txtNombre);
            txtEstado = itemView.findViewById(R.id.txtEstado);
            txtEspecie = itemView.findViewById(R.id.txtEspecie);
            btnVerMas = itemView.findViewById(R.id.btnVerMas);
        }
    }


}
