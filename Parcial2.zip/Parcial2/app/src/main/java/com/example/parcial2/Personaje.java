package com.example.parcial2;

public class Personaje {
    private String nombre;
    private String estado;
    private String especie;
    private String imagenUrl;

    public Personaje(String nombre, String estado, String especie, String imagenUrl) {
        this.nombre = nombre;
        this.estado = estado;
        this.especie = especie;
        this.imagenUrl = imagenUrl;
    }

    public String getNombre() {
        return nombre;
    }

    public String getEstado() {
        return estado;
    }

    public String getEspecie() {
        return especie;
    }

    public String getImagenUrl() {
        return imagenUrl;
    }
}
