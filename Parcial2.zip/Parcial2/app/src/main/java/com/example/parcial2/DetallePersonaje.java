package com.example.parcial2;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.squareup.picasso.Picasso;

public class DetallePersonaje extends AppCompatActivity {

    private TextView txtNombre, txtEstado, txtEspecie;
    private ImageView imgPersonaje;
    private Button btnCerrarSesion;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.detallepersonaje);

        txtNombre = findViewById(R.id.txtNombreDetalle);
        txtEstado = findViewById(R.id.txtEstadoDetalle);
        txtEspecie = findViewById(R.id.txtEspecieDetalle);
        imgPersonaje = findViewById(R.id.imgDetalle);
        btnCerrarSesion = findViewById(R.id.btnCerrarSesion);

        prefs = getSharedPreferences("MisDatos", Context.MODE_PRIVATE);


        Intent intent = getIntent();
        String nombre = intent.getStringExtra("nombre");
        String estado = intent.getStringExtra("estado");
        String especie = intent.getStringExtra("especie");
        String imagenUrl = intent.getStringExtra("imagenUrl");

        txtNombre.setText(nombre);
        txtEstado.setText(estado);
        txtEspecie.setText(especie);
        Picasso.get().load(imagenUrl).into(imgPersonaje);

        btnCerrarSesion.setOnClickListener(v -> {
            prefs.edit().clear().apply();
            Intent volver = new Intent(this, MainActivity.class);
            startActivity(volver);
            finish();
        });
    }
}
