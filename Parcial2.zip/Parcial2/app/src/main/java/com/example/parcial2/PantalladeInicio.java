package com.example.parcial2;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class PantalladeInicio extends AppCompatActivity {
    private RecyclerView recyclerViewPersonajes;
    private AdaptadorPersonaje adaptador;
    private List<Personaje> listaPersonajes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.pantalladeinicio);

        recyclerViewPersonajes = findViewById(R.id.recyclerViewPersonajes);
        recyclerViewPersonajes.setLayoutManager(new LinearLayoutManager(this));

        listaPersonajes = new ArrayList<>();


        listaPersonajes.add(new Personaje("Rick Sanchez", "Vivo", "Humano", "https://rickandmortyapi.com/api/character/avatar/1.jpeg"));
        listaPersonajes.add(new Personaje("Morty Smith", "Vivo", "Humano", "https://rickandmortyapi.com/api/character/avatar/2.jpeg"));
        listaPersonajes.add(new Personaje("Summer Smith", "Vivo", "Humano", "https://rickandmortyapi.com/api/character/avatar/3.jpeg"));
        listaPersonajes.add(new Personaje("Beth Smith", "Vivo", "Humano", "https://rickandmortyapi.com/api/character/avatar/4.jpeg"));
        listaPersonajes.add(new Personaje("Jerry Smith", "Vivo", "Humano", "https://rickandmortyapi.com/api/character/avatar/5.jpeg"));

        adaptador = new AdaptadorPersonaje(this, listaPersonajes);
        recyclerViewPersonajes.setAdapter(adaptador);
    }


}

