package com.example.parcial2;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText edtUsuario, edtContrasena;
    private Button btnLogin;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        edtUsuario = findViewById(R.id.edtUsuario);
        edtContrasena = findViewById(R.id.edtPassword);
        btnLogin = findViewById(R.id.btnIngresar);

        prefs = getSharedPreferences("MisDatos", Context.MODE_PRIVATE);

        String usuarioGuardado = prefs.getString("usuario", null);
        if (usuarioGuardado != null) {
            irPantallaInicio();
            return;
        }

        btnLogin.setOnClickListener(v -> {
            String usuario = edtUsuario.getText().toString().trim();
            String contrasena = edtContrasena.getText().toString().trim();

            if (usuario.isEmpty() || contrasena.isEmpty()) {
                Toast.makeText(this, "Debe ingresar usuario y contraseña", Toast.LENGTH_SHORT).show();
            } else {
                prefs.edit().putString("usuario", usuario).apply();
                irPantallaInicio();
            }
        });
    }

    private void irPantallaInicio() {
        Intent intent = new Intent(this, PantalladeInicio.class);
        startActivity(intent);
        finish();
    }
}
